# todoapp
A simple django todoapp

![alt text](https://cdn.scotch.io/48695/GfJiMlY8QUSRxFAM4oiV_todhom.png)
